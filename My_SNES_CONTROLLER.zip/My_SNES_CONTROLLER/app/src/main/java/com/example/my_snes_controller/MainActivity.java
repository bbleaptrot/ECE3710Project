package com.example.my_snes_controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Controller_Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Creating " + TAG);
        setContentView(R.layout.activity_main);
    }

    public void pressLeft(View view) {
        Log.d(TAG, "Pressing Left");
    }

    public void pressUp(View view) {
        Log.d(TAG, "Pressing Up");
    }

    public void pressDown(View view) {
        Log.d(TAG, "Pressing Down");
    }

    public void pressRight(View view) {
        Log.d(TAG, "Pressing Right");
    }

    public void pressB(View view) {
        Log.d(TAG, "Pressing B");
    }

    public void pressSelect(View view) {
        Log.d(TAG, "Pressing Select");
    }

    public void pressStart(View view) {
        Log.d(TAG, "Pressing Start");
    }

    public void pressA(View view) {
        Log.d(TAG, "Pressing A");
    }
}