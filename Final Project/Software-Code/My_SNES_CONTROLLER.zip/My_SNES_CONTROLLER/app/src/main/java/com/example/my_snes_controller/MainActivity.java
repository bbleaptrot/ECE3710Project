package com.example.my_snes_controller;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Controller_Activity";
//
//    // Came from DeviceList.Java from tutorial
    private BluetoothAdapter myBluetooth = null;
    private Set<BluetoothDevice> pairedDevices;
    public static String EXTRA_ADDRESS = "device_address";

    // Came from ledcontrol.java from tutorial
    String address = "98:D6:32:35:89:11";
    private ProgressDialog progress;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Creating " + TAG);
        // From DeviceList
        myBluetooth = BluetoothAdapter.getDefaultAdapter();
        if(myBluetooth == null)
        {
            //Show a mensag. that the device has no bluetooth adapter
            Toast.makeText(getApplicationContext(), "Bluetooth Device Not Available", Toast.LENGTH_LONG).show();

            //finish apk
            finish();
        }
        else if(!myBluetooth.isEnabled())
        {
            //Ask to the user turn the bluetooth on
            Intent turnBTon = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnBTon,1);
        }
        setContentView(R.layout.activity_main);
    }

    public void pressLeft(View view) {

        Log.d(TAG, "Pressing Left");
        if (btSocket!=null)
        {
            //Idea for multi-player, send an additional 0 or 1 to say 1st or 2nd player
            try
            {
                btSocket.getOutputStream().write("a".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }

    public void pressUp(View view) {

        Log.d(TAG, "Pressing Up");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("b".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }

    public void pressDown(View view) {
        Log.d(TAG, "Pressing Down");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("c".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }

    public void pressRight(View view) {
        Log.d(TAG, "Pressing Right");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("d".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }

    public void pressB(View view) {
        Log.d(TAG, "Pressing B");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("e".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,e.toString());
            }
        }
    }

    public void pressSelect(View view) {
        Log.d(TAG, "Pressing Select");
        pairedDevices = myBluetooth.getBondedDevices();

        for(BluetoothDevice bt : pairedDevices)
        {
            Log.d(TAG,bt.getName() + "\n" + bt.getAddress()); //Get the device's name and the address
        }
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("f".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,e.toString());
            }
        }
        new ConnectBT().execute(); //Call the class to connect
    }

    public void pressStart(View view) {
        Log.d(TAG, "Pressing Start");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("g".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }

    public void pressA(View view) {
        Log.d(TAG, "Pressing A");
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("h".toString().getBytes());
            }
            catch (IOException e)
            {
                Log.d(TAG,"Error");
            }
        }
    }


    // From ledControl
    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(MainActivity.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                Log.d(TAG, "FAILED TO CONNECT");
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                Log.d(TAG,"Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                Log.d(TAG,"Connected.");
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }


}